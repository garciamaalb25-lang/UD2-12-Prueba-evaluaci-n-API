// Interfaz de la respuesta de https://swapi.dev/api/films/{id}/
export interface FilmDetailResponse {
  title: string
  episode_id: number
  opening_crawl: string
  director: string
  producer: string
  release_date: string
  characters: string[]
  planets: string[]
  starships: string[]
  vehicles: string[]
  species: string[]
  created: string
  edited: string
  url: string
}
