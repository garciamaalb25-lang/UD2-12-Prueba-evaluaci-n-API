import { HttpClient } from '@angular/common/http';
import { inject, Service } from '@angular/core';
import { Observable } from 'rxjs';
import { VehicleListResponse } from '../interfaces/vehicle-list-response';
import { VehicleDetailResponse } from '../interfaces/vehicle-detail-response';

// Servicio que hace las peticiones HTTP sobre los vehículos de SWAPI
@Service()
export class VehicleService {
  private http = inject(HttpClient);

  // Obtiene el listado de vehículos
  getAllVehicles(): Observable<VehicleListResponse> {
    return this.http.get<VehicleListResponse>('https://swapi.dev/api/vehicles/');
  }

  // Obtiene el detalle de un vehículo a partir de su id
  getOneVehicle(id: string): Observable<VehicleDetailResponse> {
    return this.http.get<VehicleDetailResponse>(`https://swapi.dev/api/vehicles/${id}/`);
  }
}
