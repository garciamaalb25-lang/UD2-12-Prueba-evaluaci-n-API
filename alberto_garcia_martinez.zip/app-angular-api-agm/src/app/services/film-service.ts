import { HttpClient } from '@angular/common/http';
import { inject, Service } from '@angular/core';
import { Observable } from 'rxjs';
import { FilmListResponse } from '../interfaces/film-list-response';
import { FilmDetailResponse } from '../interfaces/film-detail-response';

// Servicio que hace las peticiones HTTP sobre las películas de SWAPI
@Service()
export class FilmService {
  private http = inject(HttpClient);

  // Obtiene el listado de películas
  getAllFilms(): Observable<FilmListResponse> {
    return this.http.get<FilmListResponse>('https://swapi.dev/api/films/');
  }

  // Obtiene el detalle de una película a partir de su id
  getOneFilm(id: string): Observable<FilmDetailResponse> {
    return this.http.get<FilmDetailResponse>(`https://swapi.dev/api/films/${id}/`);
  }
}
