import { Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Film } from '../../interfaces/film-list-response';

@Component({
  imports: [RouterLink],
  selector: 'app-film-item-component',
  host: { class: 'col-md-4 col-lg-3 mb-4' },
  styleUrl: './film-item-component.css',
  templateUrl: './film-item-component.html',
})
export class FilmItemComponent {
  // Input: la película que tiene que dibujar este componente
  film = input<Film>();

  // La url es del tipo https://swapi.dev/api/films/1/ -> el id está en la posición 5
  getFilmId(): string {
    return this.film()?.url.split('/')[5] ?? '';
  }
}
