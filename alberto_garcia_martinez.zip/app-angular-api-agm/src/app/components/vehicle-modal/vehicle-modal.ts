import { Component, inject, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { VehicleDetailResponse } from '../../interfaces/vehicle-detail-response';

@Component({
  imports: [],
  selector: 'app-vehicle-modal',
  styleUrl: './vehicle-modal.css',
  templateUrl: './vehicle-modal.html',
})
export class VehicleModal {
  // Clase de ng-bootstrap que controla el modal abierto (cerrar, descartar...)
  activeModal = inject(NgbActiveModal);

  // Detalle del vehículo que le pasamos al abrir el modal
  @Input() vehicleDetail: VehicleDetailResponse | undefined;
}
