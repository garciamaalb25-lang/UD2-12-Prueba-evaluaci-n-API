import { Component, input, output } from '@angular/core';
import { Vehicle } from '../../interfaces/vehicle-list-response';

@Component({
  imports: [],
  selector: 'app-vehicle-item-component',
  host: { class: 'col-md-4 col-lg-3 mb-4' },
  styleUrl: './vehicle-item-component.css',
  templateUrl: './vehicle-item-component.html',
})
export class VehicleItemComponent {
  // Input: el vehículo que tiene que dibujar este componente
  vehicle = input<Vehicle>();

  // Output: evento que avisa al padre del id del vehículo pulsado
  vehicleClicked = output<string>();

  // La url es del tipo https://swapi.dev/api/vehicles/4/ -> el id está en la posición 5
  getVehicleId(): string {
    return this.vehicle()?.url.split('/')[5] ?? '';
  }

  // Al hacer click emitimos el id del vehículo al componente padre
  emitVehicleClicked() {
    this.vehicleClicked.emit(this.getVehicleId());
  }
}
