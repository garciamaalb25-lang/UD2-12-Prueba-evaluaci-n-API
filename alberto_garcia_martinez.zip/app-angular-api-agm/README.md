# app-angular-api-agm

Ejercicio PMDM – Alberto García Martínez.

App Angular que consume la API pública de Star Wars (https://swapi.dev) usando Bootstrap y ng-bootstrap.

## Ejecutar

```bash
npm install
npm start
```

Abrir http://localhost:4200 (por defecto carga la lista de vehículos).

## Estructura

```
src/app
├── interfaces/        Interfaces de las respuestas del API (lista y detalle)
├── services/          VehicleService y FilmService (peticiones HTTP)
├── components/
│   ├── menu-toolbar/          Menú con los enlaces "Vehicles" y "Films"
│   ├── vehicle-item-component Tarjeta de un vehículo (input vehicle + output vehicleClicked)
│   ├── vehicle-modal/         Modal ng-bootstrap con el detalle del vehículo
│   └── film-item-component/   Tarjeta de un film (routerLink a /film-detail/:id)
└── pages/
    ├── vehicles-list-page/    Ejercicio 1: listado de vehículos + apertura del modal
    ├── film-list-page/        Ejercicio 2: listado de films
    ├── film-item-page/        Ejercicio 2: detalle del film leyendo el :id de la ruta
    └── not-found/             Página 404
```

## Rutas

| Ruta               | Componente         |
|--------------------|--------------------|
| `/vehicle-list`    | VehiclesListPage   |
| `/film-list`       | FilmListPage       |
| `/film-detail/:id` | FilmItemPage       |
| `''`               | redirige a `/vehicle-list` |
| `**`               | NotFound           |
